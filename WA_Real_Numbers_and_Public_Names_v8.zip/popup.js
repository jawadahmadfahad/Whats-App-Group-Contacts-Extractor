document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('groupsListContainer');
  const searchInput = document.getElementById('searchInput');
  const statusMsg = document.getElementById('statusMsg');
  const extractBtn = document.getElementById('extractBtn');
  const toggleSelectAll = document.getElementById('toggleSelectAll');
  const selectedCountText = document.getElementById('selectedCountText');

  const tabAll = document.getElementById('tabAll');
  const tabGroups = document.getElementById('tabGroups');
  const tabCommunities = document.getElementById('tabCommunities');

  const allCountSpan = document.getElementById('allCount');
  const groupCountSpan = document.getElementById('groupCount');
  const commCountSpan = document.getElementById('commCount');

  let rawList = [];
  let currentFilterType = 'all';
  let selectAllState = false;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url.includes('web.whatsapp.com')) {
    container.innerHTML = '<div class="loading-text" style="color:#dc2626;">Please open WhatsApp Web first!</div>';
    extractBtn.disabled = true;
    return;
  }

  statusMsg.className = 'status-msg info';
  statusMsg.innerText = 'Scanning all groups & member counts...';

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    func: scanWhatsAppGroupsEngine
  }, (results) => {
    if (chrome.runtime.lastError || !results || !results[0]) {
      container.innerHTML = '<div class="loading-text" style="color:#dc2626;">Please refresh WhatsApp Web (F5) and open extension again.</div>';
      statusMsg.innerText = '';
      return;
    }

    rawList = results[0].result || [];
    if (rawList.length === 0) {
      container.innerHTML = '<div class="loading-text">No groups found. Please ensure chats are loaded.</div>';
      statusMsg.innerText = '';
      return;
    }

    const gCount = rawList.filter(x => !x.isCommunity).length;
    const cCount = rawList.filter(x => x.isCommunity).length;
    allCountSpan.innerText = rawList.length;
    groupCountSpan.innerText = gCount;
    commCountSpan.innerText = cCount;

    statusMsg.innerText = '';
    renderFilteredList();
  });

  [tabAll, tabGroups, tabCommunities].forEach(btn => {
    btn.addEventListener('click', () => {
      [tabAll, tabGroups, tabCommunities].forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (btn === tabAll) currentFilterType = 'all';
      else if (btn === tabGroups) currentFilterType = 'group';
      else if (btn === tabCommunities) currentFilterType = 'community';
      renderFilteredList();
    });
  });

  searchInput.addEventListener('input', () => {
    renderFilteredList();
  });

  function renderFilteredList() {
    const query = searchInput.value.toLowerCase().trim();
    let filtered = rawList.filter(item => {
      if (currentFilterType === 'group' && item.isCommunity) return false;
      if (currentFilterType === 'community' && !item.isCommunity) return false;
      if (query && !item.name.toLowerCase().includes(query)) return false;
      return true;
    });

    container.innerHTML = '';
    if (filtered.length === 0) {
      container.innerHTML = '<div class="loading-text">No matching group or community found.</div>';
      updateSelectedCount();
      return;
    }

    filtered.forEach(item => {
      const label = document.createElement('label');
      label.className = 'group-item';
      const countDisplay = item.count > 0 ? `${item.count} members` : (item.isActive ? 'Active Group' : 'Group');
      label.innerHTML = `
        <input type="checkbox" class="group-checkbox" value="${item.id}" ${item.checked ? 'checked' : ''}>
        <div class="group-meta">
          <div class="group-header-row">
            <span class="group-name" title="${item.name}">${item.name}</span>
            <span class="group-type-tag ${item.isCommunity ? 'tag-comm' : 'tag-group'}">${item.isCommunity ? 'Community' : 'Group'}</span>
          </div>
          <div class="group-count">${countDisplay}</div>
        </div>
      `;
      const cb = label.querySelector('.group-checkbox');
      cb.addEventListener('change', () => {
        item.checked = cb.checked;
        updateSelectedCount();
      });
      container.appendChild(label);
    });

    updateSelectedCount();
  }

  function updateSelectedCount() {
    const count = rawList.filter(x => x.checked).length;
    selectedCountText.innerText = `${count} selected`;
  }

  toggleSelectAll.addEventListener('click', () => {
    selectAllState = !selectAllState;
    const query = searchInput.value.toLowerCase().trim();
    rawList.forEach(item => {
      const matchesType = currentFilterType === 'all' || 
                         (currentFilterType === 'group' && !item.isCommunity) || 
                         (currentFilterType === 'community' && item.isCommunity);
      const matchesQuery = !query || item.name.toLowerCase().includes(query);
      if (matchesType && matchesQuery) {
        item.checked = selectAllState;
      }
    });
    toggleSelectAll.innerText = selectAllState ? 'Deselect All' : 'Select All';
    renderFilteredList();
  });

  extractBtn.addEventListener('click', async () => {
    const selected = rawList.filter(x => x.checked);

    if (selected.length === 0) {
      statusMsg.className = 'status-msg error';
      statusMsg.innerText = 'Please select at least one group!';
      return;
    }

    const format = document.querySelector('input[name="format"]:checked').value;
    const includeAdmin = document.getElementById('includeAdmins').checked;

    extractBtn.disabled = true;
    statusMsg.className = 'status-msg info';
    statusMsg.innerText = 'Resolving REAL +92 numbers & Public WhatsApp Names...';

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: extractRealNumbersAndPublicNamesEngineV8,
      args: [selected, format, includeAdmin]
    }, (results) => {
      extractBtn.disabled = false;
      if (chrome.runtime.lastError || !results || !results[0]) {
        statusMsg.className = 'status-msg error';
        statusMsg.innerText = 'Error: ' + (chrome.runtime.lastError?.message || 'Execution failed');
        return;
      }

      const res = results[0].result;
      if (res && res.success) {
        statusMsg.className = 'status-msg success';
        statusMsg.innerText = `Done! Successfully downloaded all ${res.count} contacts!`;
      } else {
        statusMsg.className = 'status-msg error';
        statusMsg.innerText = res?.message || 'No contacts found.';
      }
    });
  });
});

// ================= INJECTED SCAN ENGINE =================

function scanWhatsAppGroupsEngine() {
  const groupsMap = new Map();

  function getChatFromNode(node) {
    if (!node) return null;
    const fiberKey = Object.keys(node).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
    if (!fiberKey) return null;
    let curr = node[fiberKey];
    while (curr) {
      if (curr.memoizedProps) {
        const p = curr.memoizedProps;
        if (p.chat) return p.chat;
        if (p.data && p.data.chat) return p.data.chat;
        if (p.conversation) return p.conversation;
      }
      curr = curr.return;
    }
    return null;
  }

  const header = document.querySelector('header');
  let activeChatTitle = "";
  let activeMemberCount = 0;

  const headerSubtitleEl = document.querySelector('header span[title]')?.parentElement?.parentElement;
  if (headerSubtitleEl) {
    const txt = headerSubtitleEl.innerText || "";
    const m = txt.match(/(\d[\d\s,]*)\s*members?/i);
    if (m) {
      activeMemberCount = parseInt(m[1].replace(/[^\d]/g, ''), 10);
    }
  }

  if (header) {
    const activeChat = getChatFromNode(header);
    if (activeChat) {
      const name = activeChat.name || activeChat.formattedTitle || "Active Group";
      activeChatTitle = name;
      const cid = activeChat.id?._serialized || activeChat.id || "active_group_1";
      let parts = activeChat.groupMetadata?.participants || [];
      if (parts.models) parts = parts.models;
      let count = parts.length || activeMemberCount;

      groupsMap.set(name, {
        id: cid,
        name: name,
        isCommunity: Boolean(activeChat.isParentGroup),
        count: count,
        isActive: true,
        checked: true
      });
    }
  }

  const cells = document.querySelectorAll('div[data-testid="cell-frame-container"], div[role="listitem"]');
  cells.forEach(cell => {
    const chat = getChatFromNode(cell);
    if (chat && (chat.isGroup || chat.id?._serialized?.includes('@g.us') || chat.isParentGroup)) {
      const name = chat.name || chat.formattedTitle || "Group";
      const cid = chat.id?._serialized || chat.id;
      let parts = chat.groupMetadata?.participants || [];
      if (parts.models) parts = parts.models;
      let count = parts.length || 0;
      if (name === activeChatTitle && activeMemberCount > count) count = activeMemberCount;

      if (!groupsMap.has(name) || groupsMap.get(name).count === 0) {
        groupsMap.set(name, {
          id: cid,
          name: name,
          isCommunity: Boolean(chat.isParentGroup),
          count: count,
          isActive: name === activeChatTitle,
          checked: name === activeChatTitle
        });
      }
    }
  });

  try {
    let store = window.Store;
    if (!store && window.webpackChunkwhatsapp_web_client) {
      window.webpackChunkwhatsapp_web_client.push([["parasite_sc_" + Date.now()], {}, (e) => { store = e; }]);
    }
    if (store) {
      const chats = (store.Chat && (store.Chat.models || store.Chat._models)) || 
                    Object.values(store).find(m => m && m.Chat)?.Chat?.models;
      if (chats) {
        chats.forEach(c => {
          const cid = c.id?._serialized || c.id;
          if (cid && (c.isGroup || cid.includes('@g.us') || c.isParentGroup)) {
            const name = c.name || c.formattedTitle || "Group";
            let parts = c.groupMetadata?.participants || [];
            if (parts.models) parts = parts.models;
            let count = parts.length || 0;

            if (name === activeChatTitle && activeMemberCount > count) count = activeMemberCount;

            if (!groupsMap.has(name)) {
              groupsMap.set(name, {
                id: cid,
                name: name,
                isCommunity: Boolean(c.isParentGroup),
                count: count,
                isActive: name === activeChatTitle,
                checked: name === activeChatTitle
              });
            } else if (count > 0 && groupsMap.get(name).count === 0) {
              groupsMap.get(name).count = count;
            }
          }
        });
      }
    }
  } catch(e) {}

  if (activeChatTitle && groupsMap.has(activeChatTitle) && activeMemberCount > 0) {
    groupsMap.get(activeChatTitle).count = activeMemberCount;
  }

  return Array.from(groupsMap.values()).sort((a, b) => {
    if (a.isActive) return -1;
    if (b.isActive) return 1;
    return (b.count || 0) - (a.count || 0);
  });
}

// ================= ULTIMATE RESOLVER (REAL PHONES + PUBLIC PUSHNAMES) =================

async function extractRealNumbersAndPublicNamesEngineV8(selectedItems, format, includeAdmin) {
  try {
    const selectedNames = selectedItems.map(x => x.name.toLowerCase().trim());
    const selectedIds = selectedItems.map(x => x.id);

    // Dictionaries for mapping
    const lidToPhone = new Map();
    const lidToPushname = new Map();
    const phoneToPushname = new Map();
    const savedNames = new Map();

    // 1. Build Global Contact Dictionary from IndexedDB
    try {
      const dbs = await indexedDB.databases();
      for (const dbInfo of dbs) {
        if (!dbInfo.name) continue;
        await new Promise((resolve) => {
          const req = indexedDB.open(dbInfo.name);
          req.onsuccess = async (e) => {
            const db = e.target.result;
            const storeNames = Array.from(db.objectStoreNames);
            const contactStores = storeNames.filter(s => s.toLowerCase().includes('contact'));

            for (const cs of contactStores) {
              try {
                const tx = db.transaction([cs], 'readonly');
                const store = tx.objectStore(cs);
                const allContacts = await new Promise(res => {
                  const r = store.getAll();
                  r.onsuccess = () => res(r.result || []);
                  r.onerror = () => res([]);
                });

                allContacts.forEach(c => {
                  const rawId = c.id?._serialized || String(c.id || '');
                  const rawLid = c.lid?._serialized || String(c.lid || '');
                  const rawPhone = c.phoneNumber ? String(c.phoneNumber) : (rawId.includes('@c.us') ? rawId.split('@')[0] : '');
                  const pushname = c.pushname || c.notifyName || c.verifiedName || '';
                  const name = c.name || '';

                  let cleanPhone = '';
                  if (rawPhone) {
                    const d = rawPhone.replace(/\D/g, '');
                    if (d.length >= 10 && d.length <= 15) cleanPhone = '+' + d;
                  }

                  if (cleanPhone) {
                    if (rawLid) lidToPhone.set(rawLid, cleanPhone);
                    if (rawId.includes('@lid')) lidToPhone.set(rawId, cleanPhone);
                    if (pushname) phoneToPushname.set(cleanPhone, pushname);
                    if (name) savedNames.set(cleanPhone, name);
                  }

                  if (rawLid && pushname) lidToPushname.set(rawLid, pushname);
                  if (rawId.includes('@lid') && pushname) lidToPushname.set(rawId, pushname);
                });
              } catch(err) {}
            }
            db.close();
            resolve();
          };
          req.onerror = () => resolve();
        });
      }
    } catch(e) {}

    // 2. Build from Runtime window.Store
    try {
      let store = window.Store;
      if (!store && window.webpackChunkwhatsapp_web_client) {
        window.webpackChunkwhatsapp_web_client.push([["parasite_dict_" + Date.now()], {}, (e) => { store = e; }]);
      }
      if (store) {
        const contactModels = (store.Contact && (store.Contact.models || store.Contact._models)) || 
                              Object.values(store).find(m => m && m.Contact)?.Contact?.models;
        if (contactModels) {
          contactModels.forEach(c => {
            const rawId = c.id?._serialized || String(c.id || '');
            const rawLid = c.lid?._serialized || String(c.lid || '');
            const rawPhone = c.phoneNumber ? String(c.phoneNumber) : (rawId.includes('@c.us') ? rawId.split('@')[0] : '');
            const pushname = c.pushname || c.notifyName || '';
            const name = c.name || '';

            let cleanPhone = '';
            if (rawPhone) {
              const d = rawPhone.replace(/\D/g, '');
              if (d.length >= 10 && d.length <= 15) cleanPhone = '+' + d;
            }

            if (cleanPhone) {
              if (rawLid) lidToPhone.set(rawLid, cleanPhone);
              if (rawId.includes('@lid')) lidToPhone.set(rawId, cleanPhone);
              if (pushname) phoneToPushname.set(cleanPhone, pushname);
              if (name) savedNames.set(cleanPhone, name);
            }

            if (rawLid && pushname) lidToPushname.set(rawLid, pushname);
            if (rawId.includes('@lid') && pushname) lidToPushname.set(rawId, pushname);
          });
        }
      }
    } catch(e) {}

    // 3. Collect Participants from Group
    const collectedRecords = [];

    function getChatFromNode(node) {
      if (!node) return null;
      const fiberKey = Object.keys(node).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
      if (!fiberKey) return null;
      let curr = node[fiberKey];
      while (curr) {
        if (curr.memoizedProps) {
          const p = curr.memoizedProps;
          if (p.chat) return p.chat;
          if (p.data && p.data.chat) return p.data.chat;
          if (p.conversation) return p.conversation;
        }
        curr = curr.return;
      }
      return null;
    }

    function processParticipant(p, groupName) {
      if (!p) return;
      const rawId = p.id?._serialized || p.id?.user || String(p.id || p.user || '');
      const isAdmin = Boolean(p.isAdmin || p.isSuperAdmin || (p.rank === 'admin'));
      if (isAdmin && !includeAdmin) return;

      // Extract real phone
      let realPhone = '';
      if (rawId.includes('@c.us') || (!rawId.includes('@lid') && (rawId.startsWith('92') || rawId.startsWith('1')))) {
        const d = rawId.split('@')[0].replace(/\D/g, '');
        if (d.length >= 10 && d.length <= 15) realPhone = '+' + d;
      }

      if (!realPhone && p.phoneNumber) {
        const d = String(p.phoneNumber).replace(/\D/g, '');
        if (d.length >= 10 && d.length <= 15) realPhone = '+' + d;
      }

      if (!realPhone && p.contact?.phoneNumber) {
        const d = String(p.contact.phoneNumber).replace(/\D/g, '');
        if (d.length >= 10 && d.length <= 15) realPhone = '+' + d;
      }

      // Check dictionary from LID
      if (!realPhone && lidToPhone.has(rawId)) {
        realPhone = lidToPhone.get(rawId);
      }

      // Check name for phone string (+92 340 84...)
      if (!realPhone) {
        const testStrings = [p.name, p.notifyName, p.contact?.name, p.contact?.pushname];
        for (let s of testStrings) {
          if (s && typeof s === 'string' && (s.startsWith('+') || /^\d[\d\s-]{9,}/.test(s))) {
            const d = s.replace(/\D/g, '');
            if (d.length >= 10 && d.length <= 15) {
              realPhone = '+' + d;
              break;
            }
          }
        }
      }

      // Fallback: if STILL not resolved, format raw number cleanly
      if (!realPhone) {
        const d = rawId.replace(/\D/g, '');
        realPhone = '+' + d;
      }

      // Resolve Public Name (Push Name) and Saved Name
      let publicName = p.pushname || p.contact?.pushname || p.notifyName || p.contact?.notifyName || '';
      if (!publicName && lidToPushname.has(rawId)) publicName = lidToPushname.get(rawId);
      if (!publicName && phoneToPushname.has(realPhone)) publicName = phoneToPushname.get(realPhone);

      let savedName = p.name || p.contact?.name || '';
      if (!savedName && savedNames.has(realPhone)) savedName = savedNames.get(realPhone);

      // Clean up if savedName is just the phone number itself
      if (savedName && savedName.replace(/\D/g, '') === realPhone.replace(/\D/g, '')) {
        savedName = '';
      }

      collectedRecords.push({
        phone: realPhone,
        publicName: publicName,
        savedName: savedName,
        group: groupName,
        role: isAdmin ? 'Admin' : 'Member'
      });
    }

    // A. Active Chat Header React Fiber
    const header = document.querySelector('header');
    if (header) {
      const activeChat = getChatFromNode(header);
      if (activeChat) {
        const chatTitle = activeChat.name || activeChat.formattedTitle || "WhatsApp Group";
        if (selectedNames.includes(chatTitle.toLowerCase().trim()) || selectedIds.includes(activeChat.id?._serialized)) {
          let parts = activeChat.groupMetadata?.participants || [];
          if (parts.models) parts = parts.models;
          parts.forEach(p => processParticipant(p, chatTitle));
        }
      }
    }

    // B. Webpack Store
    if (collectedRecords.length === 0) {
      try {
        let store = window.Store;
        if (store) {
          const chats = (store.Chat && (store.Chat.models || store.Chat._models)) || 
                        Object.values(store).find(m => m && m.Chat)?.Chat?.models;
          if (chats) {
            chats.forEach(chat => {
              const chatTitle = (chat.name || chat.formattedTitle || "").toLowerCase().trim();
              const cid = chat.id?._serialized || chat.id;
              if (selectedNames.includes(chatTitle) || selectedIds.includes(cid)) {
                let parts = chat.groupMetadata?.participants || [];
                if (parts.models) parts = parts.models;
                parts.forEach(p => processParticipant(p, chat.name || "WhatsApp Group"));
              }
            });
          }
        }
      } catch(e) {}
    }

    // C. IndexedDB Group Metadata
    if (collectedRecords.length === 0) {
      try {
        const dbs = await indexedDB.databases();
        for (const dbInfo of dbs) {
          if (!dbInfo.name) continue;
          await new Promise((resolve) => {
            const req = indexedDB.open(dbInfo.name);
            req.onsuccess = async (e) => {
              const db = e.target.result;
              const metaStores = Array.from(db.objectStoreNames).filter(s => s.toLowerCase().includes('group'));
              for (const ms of metaStores) {
                try {
                  const tx = db.transaction([ms], 'readonly');
                  const store = tx.objectStore(ms);
                  const records = await new Promise(res => {
                    const r = store.getAll();
                    r.onsuccess = () => res(r.result || []);
                    r.onerror = () => res([]);
                  });
                  records.forEach(r => {
                    const gid = r.id?._serialized || r.id;
                    if ((selectedIds.includes(gid) || selectedNames.length === 1) && r.participants) {
                      r.participants.forEach(p => processParticipant(p, selectedItems[0]?.name || "Group"));
                    }
                  });
                } catch(err) {}
              }
              db.close();
              resolve();
            };
            req.onerror = () => resolve();
          });
        }
      } catch(e) {}
    }

    // Remove duplicates
    const uniqueMap = new Map();
    collectedRecords.forEach(item => {
      const key = item.phone + '_' + item.group;
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, item);
      } else {
        // Prefer record with publicName if existing is empty
        const existing = uniqueMap.get(key);
        if (!existing.publicName && item.publicName) existing.publicName = item.publicName;
        if (!existing.savedName && item.savedName) existing.savedName = item.savedName;
      }
    });

    const finalContacts = Array.from(uniqueMap.values());
    if (finalContacts.length === 0) {
      return { success: false, message: "No contacts found. Please open group and try again." };
    }

    // Export with 4 Clear Columns:
    // Phone Number | Public Name (WhatsApp Name) | Saved Name | Group | Role
    let blob, ext;
    const fileNameSafe = selectedItems[0]?.name?.replace(/[^a-zA-Z0-9_-]/g, '_') || 'WA_Group';

    if (format === 'csv') {
      const rows = ['"Phone Number","Public Name (WhatsApp Name)","Saved Name (Contacts)","Group","Role"'];
      finalContacts.forEach(c => {
        rows.push(`"\t${c.phone}","${c.publicName.replace(/"/g, '""')}","${c.savedName.replace(/"/g, '""')}","${c.group.replace(/"/g, '""')}","${c.role}"`);
      });
      blob = new Blob(["\uFEFF" + rows.join("\r\n")], { type: "text/csv;charset=utf-8;" });
      ext = "csv";
    } else if (format === 'json') {
      blob = new Blob([JSON.stringify(finalContacts, null, 2)], { type: "application/json" });
      ext = "json";
    } else {
      const txtLines = finalContacts.map(c => `${c.phone} - ${c.publicName || c.savedName || 'No Name'}`);
      blob = new Blob([txtLines.join("\r\n")], { type: "text/plain;charset=utf-8;" });
      ext = "txt";
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileNameSafe}_${finalContacts.length}_Contacts.${ext}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    return { success: true, count: finalContacts.length };
  } catch(e) {
    return { success: false, message: e.message };
  }
}
